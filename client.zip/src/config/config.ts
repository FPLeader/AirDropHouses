const crypto = {
  ETH: 'ETH',
};

const config = {
  price: 0.15,
  type: crypto.ETH,

  discord_url: 'https://discord.gg/airdrophouses',
  instagram_url: 'https://www.instagram.com/airdrophouses',
  facebook_url: 'https://www.facebook.com/airdrophouses',
  twitter_url: 'https://twitter.com/airdrophouses',
  companies: {
    coOper_data_1: 'AIRDROP',
    coOper_data_2: 'HHEC',
    coOper_data_3: '',
    coOper_data_4: '',
    coOper_data_5: '',
  },
};

export default config;
