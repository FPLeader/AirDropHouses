export function getFullName(shortened: string) {
  return shortened === 'en' ? 'ENGLISH' : '繁體中文';
}
