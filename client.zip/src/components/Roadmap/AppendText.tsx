const AppendText = () => {
  return (
    <span className='md:hidden text-white text-[18px] md:text-[16px] lg:text-[18px] leading-[31px]'>
      賦能籌備
    </span>
  );
};

export default AppendText;
