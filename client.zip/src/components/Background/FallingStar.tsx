const FallingStar = () => {
  return (
    <section className='star-fall-section'>
      <span className='starfall' />
      <span className='starfall' />
      <span className='starfall' />
      <span className='starfall' />
      <span className='starfall' />
      <span className='starfall' />
      <span className='starfall' />
      <span className='starfall' />
      <span className='starfall' />
      <span className='starfall' />
    </section>
  );
};

export default FallingStar;
