const MintNow = () => {
  return (
    <button className='w-full h-[29px] md:h-[46px] rounded-[8px] bg-gradient-to-r from-[#F2974A] to-[#F4E077] text-center text-black font-bold'>
      購買NFT
    </button>
  );
};

export default MintNow;
