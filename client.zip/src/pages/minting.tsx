import MintLayout from '../layout/mint';
import MintSection from './minting-sections/MintSection';

const MintingPage = () => {
  return (
    <MintLayout>
      <MintSection />
    </MintLayout>
  );
};

export default MintingPage;
